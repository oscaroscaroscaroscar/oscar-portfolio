# Oscar Apple Portfolio

Next.js portfolio med Apple-inspirerad design, 3D-bakgrund, glassmorphism, låsta projektkort, bloggstruktur, Stripe-route och AI-chat widget.

## Starta lokalt

```bash
npm install
cp .env.example .env.local
npm run dev
```

Öppna: http://localhost:3000

## Kod för låsta projektkort

Standardkoden är:

```txt
OSCAR2026
```

Vill du ändra koden, lägg till detta i `.env.local`:

```bash
NEXT_PUBLIC_PROJECT_ACCESS_CODE=DIN_KOD_HÄR
```

## Deploy till Vercel

1. Ladda upp projektet till GitHub.
2. Importera GitHub-repot i Vercel.
3. Klicka Deploy.
