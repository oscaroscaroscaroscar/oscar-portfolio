import type { Config } from 'tailwindcss';
const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: { extend: { boxShadow: { glow: '0 0 60px rgba(99,102,241,.45)' } } },
  plugins: []
};
export default config;
