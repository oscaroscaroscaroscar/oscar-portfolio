'use client';
import Link from 'next/link';
import { useTheme } from 'next-themes';
import { Moon, Sun } from 'lucide-react';

export default function Navbar() {
  const { theme, setTheme } = useTheme();
  return (
    <nav className="fixed left-1/2 top-4 z-50 flex w-[92%] max-w-6xl -translate-x-1/2 items-center justify-between rounded-full border border-white/10 bg-black/50 px-5 py-3 backdrop-blur-2xl">
      <Link href="/" className="font-semibold">Oscar Åberg</Link>
      <div className="hidden gap-5 text-sm text-white/70 md:flex">
        <Link href="/about">Om mig</Link><Link href="/projects">Projekt</Link><Link href="/blog">Blogg</Link><Link href="/pricing">Priser</Link>
      </div>
      <button onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} className="rounded-full border border-white/10 p-2">
        {theme === 'dark' ? <Sun size={18}/> : <Moon size={18}/>} 
      </button>
    </nav>
  );
}
