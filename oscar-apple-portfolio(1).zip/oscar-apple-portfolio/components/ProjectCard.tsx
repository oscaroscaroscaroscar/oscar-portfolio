'use client';
import { useState } from 'react';
import GlassCard from './GlassCard';

const ACCESS_CODE = process.env.NEXT_PUBLIC_PROJECT_ACCESS_CODE || 'OSCAR2026';

export default function ProjectCard({ title, description, tools }: { title: string; description: string; tools: string[] }) {
  const [code, setCode] = useState('');
  const [unlocked, setUnlocked] = useState(false);
  return (
    <GlassCard className="min-h-[230px]">
      {!unlocked ? <div className="space-y-4"><h3 className="text-xl font-semibold">🔒 Skyddat projekt</h3><p className="text-white/60">Ange åtkomstkod för att visa innehåll.</p><input className="input" type="password" value={code} onChange={(e)=>setCode(e.target.value)} placeholder="Ange kod"/><button className="button" onClick={()=> code === ACCESS_CODE ? setUnlocked(true) : alert('Fel kod')}>Lås upp</button></div> : <div className="space-y-4"><h3 className="text-2xl font-semibold">{title}</h3><p className="text-white/70">{description}</p><div className="flex flex-wrap gap-2">{tools.map(t=><span key={t} className="rounded-full border border-white/10 px-3 py-1 text-xs text-white/60">{t}</span>)}</div></div>}
    </GlassCard>
  );
}
