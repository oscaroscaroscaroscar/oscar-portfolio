'use client';
import { Canvas } from '@react-three/fiber';
import { Float, MeshDistortMaterial, OrbitControls } from '@react-three/drei';

function Shape({ position, color }: any) {
  return <Float speed={2} rotationIntensity={1} floatIntensity={2}><mesh position={position}><icosahedronGeometry args={[1.3, 2]} /><MeshDistortMaterial color={color} distort={0.35} speed={2} roughness={0.2} /></mesh></Float>;
}
export default function Background3D() {
  return <div className="pointer-events-none absolute inset-0 -z-10 opacity-60"><Canvas camera={{ position: [0, 0, 7] }}><ambientLight intensity={1}/><pointLight position={[5,5,5]} intensity={2}/><Shape position={[-3,1,0]} color="#7c3aed"/><Shape position={[3,-1,0]} color="#06b6d4"/><OrbitControls enableZoom={false} enablePan={false}/></Canvas></div>;
}
