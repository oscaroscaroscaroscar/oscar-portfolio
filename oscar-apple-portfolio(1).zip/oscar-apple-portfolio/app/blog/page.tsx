import GlassCard from '@/components/GlassCard';
const posts=['Från idé till digital produkt','Design, fokus och enkelhet','Musik, media och digital närvaro'];
export default function Blog(){return <main className="min-h-screen px-6 pt-32"><section className="mx-auto max-w-5xl"><h1 className="text-5xl font-bold">Loggbok</h1><div className="mt-10 grid gap-6">{posts.map(p=><GlassCard key={p}><h2 className="text-2xl font-semibold">{p}</h2><p className="mt-2 text-white/60">Kommande blogginlägg kopplat till Sanity CMS.</p></GlassCard>)}</div></section></main>}
