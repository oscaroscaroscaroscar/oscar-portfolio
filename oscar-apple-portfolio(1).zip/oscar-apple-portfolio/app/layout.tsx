import './globals.css';
import type { Metadata } from 'next';
import { ThemeProvider } from 'next-themes';
import Navbar from '@/components/Navbar';
import AIChat from '@/components/AIChat';

export const metadata: Metadata = {
  title: 'Oscar Åberg – Digital Portfolio',
  description: 'Digitala produkter, webbplattformar och kreativa projekt.',
  openGraph: { title: 'Oscar Åberg', description: 'Digital portfolio och kreativa projekt.', type: 'website' }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="sv" suppressHydrationWarning>
      <body>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          <Navbar />
          {children}
          <AIChat />
        </ThemeProvider>
      </body>
    </html>
  );
}
