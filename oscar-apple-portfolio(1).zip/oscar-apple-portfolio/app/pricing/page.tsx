import GlassCard from '@/components/GlassCard';
const plans=[['Starter','99 kr/mån'],['Pro','299 kr/mån'],['Enterprise','Kontakta mig']];
export default function Pricing(){return <main className="min-h-screen px-6 pt-32"><section className="mx-auto max-w-6xl"><h1 className="text-5xl font-bold">Priser</h1><div className="mt-10 grid gap-6 md:grid-cols-3">{plans.map(([name,price])=><GlassCard key={name}><h2 className="text-2xl font-semibold">{name}</h2><p className="mt-4 text-3xl font-bold">{price}</p><button className="button mt-6">Välj</button></GlassCard>)}</div></section></main>}
