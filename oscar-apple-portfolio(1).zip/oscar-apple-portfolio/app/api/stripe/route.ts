import { NextResponse } from 'next/server';
export async function POST(){return NextResponse.json({message:'Stripe route är redo. Lägg till STRIPE_SECRET_KEY i .env.local.'});}
