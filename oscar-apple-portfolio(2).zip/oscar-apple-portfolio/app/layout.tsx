import './globals.css';
import type { Metadata } from 'next';
import { ThemeProvider } from '@/components/ThemeProvider';

export const metadata: Metadata = {
  title: 'Oscar Åberg — Digitala Produkter & Portfolio',
  description: 'Personlig portfolio för digitala produkter, webbplattformar och kreativa projekt.',
  openGraph: {
    title: 'Oscar Åberg — Portfolio',
    description: 'Digitala produkter, webbplattformar och kreativa projekt.',
    type: 'website'
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="sv" suppressHydrationWarning>
      <body>
        <ThemeProvider>{children}</ThemeProvider>
      </body>
    </html>
  );
}
