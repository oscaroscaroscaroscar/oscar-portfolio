import ProjectCard from "@/components/ProjectCard";

const projects = [
  { title: "CollectorsMarket AI", category: "Kod & Appar", description: "AI-first marknadsplats för samlarobjekt: bildanalys, prisförslag, köparmatchning, bud och bedrägeriskydd.", tools: ["Next.js", "Supabase", "OpenAI", "Stripe"] },
  { title: "Musikgenerator AI", category: "Musik", description: "Automatiserad musikplattform som genererar texter, omslag, metadata och låtar i flera språk och genrer.", tools: ["Python", "React", "OpenAI", "Cloud Storage"] },
  { title: "Personlig Apple Portfolio", category: "Webb", description: "Den här hemsidan: 3D, glassmorphism, blogg, AI-chat, Stripe och deploy via Vercel.", tools: ["Next.js", "Framer Motion", "Three.js", "Sanity"] },
  { title: "Visit Every Country", category: "Resor", description: "Optimerad 24-månaders reseplan för att besöka världens länder med svenskt pass och medelbudget.", tools: ["Research", "PDF", "Planning", "Automation"] }
];

export default function ProjectsPage() {
  return (
    <main className="mx-auto min-h-screen max-w-6xl px-6 pt-36 pb-24">
      <h1 className="text-5xl font-bold">Projekt & Portfolio</h1>
      <div className="mt-10 grid gap-6 md:grid-cols-2">
        {projects.map((p) => <ProjectCard key={p.title} {...p} />)}
      </div>
    </main>
  );
}
