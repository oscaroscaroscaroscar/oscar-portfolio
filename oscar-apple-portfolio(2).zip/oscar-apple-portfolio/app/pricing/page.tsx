import GlassCard from "@/components/GlassCard";

export default function PricingPage() {
  return (
    <main className="mx-auto min-h-screen max-w-5xl px-6 pt-36 pb-24">
      <h1 className="text-5xl font-bold">SaaS / Pricing</h1>
      <div className="mt-10 grid gap-6 md:grid-cols-3">
        {[
          ["Free", "0 kr", "Portfolio och publika projekt"],
          ["Pro", "99 kr/mån", "AI-assistent, premiuminnehåll och extra resurser"],
          ["Custom", "Offert", "Samarbeten, konsulting och specialprojekt"]
        ].map(([name, price, desc]) => (
          <GlassCard key={name}>
            <h2 className="text-2xl font-bold">{name}</h2>
            <p className="mt-4 text-3xl font-bold">{price}</p>
            <p className="mt-3 opacity-70">{desc}</p>
            <form action="/api/stripe" method="POST">
              <button className="mt-6 w-full rounded-full bg-white px-5 py-3 font-semibold text-black">Kom igång</button>
            </form>
          </GlassCard>
        ))}
      </div>
    </main>
  );
}
