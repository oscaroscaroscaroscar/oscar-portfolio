import GlassCard from "@/components/GlassCard";

export default function AboutPage() {
  return (
    <main className="mx-auto min-h-screen max-w-5xl px-6 pt-36 pb-24">
      <h1 className="text-5xl font-bold">Om mig</h1>
      <GlassCard className="mt-8">
        <p className="text-lg leading-8 opacity-80">
          Jag är Oscar Åberg, en kreativ teknikbyggare med fokus på AI, automation, digitala produkter och moderna webbupplevelser. Jag gillar att ta idéer från koncept till fungerande system: appar, marknadsplatser, AI-assistenter, musikverktyg och portfolio/SaaS-projekt.
        </p>
      </GlassCard>
      <div className="mt-8 grid gap-6 md:grid-cols-3">
        {['Kreativitet', 'Teknisk innovation', 'Noggrannhet'].map((v) => (
          <GlassCard key={v}><h2 className="text-2xl font-bold">{v}</h2><p className="mt-2 opacity-70">En viktig princip i hur jag bygger och utvecklar projekt.</p></GlassCard>
        ))}
      </div>
    </main>
  );
}
