import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  const { message } = await req.json();
  if (!process.env.OPENAI_API_KEY) {
    return NextResponse.json({ reply: `Demoläge: Du skrev "${message}". Lägg till OPENAI_API_KEY i .env.local för riktig chat.` });
  }
  return NextResponse.json({ reply: 'Chat API är redo. Koppla valfri OpenAI SDK här.' });
}
