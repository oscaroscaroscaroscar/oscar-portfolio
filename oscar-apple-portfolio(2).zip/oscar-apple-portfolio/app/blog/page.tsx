import GlassCard from "@/components/GlassCard";
import { sanityClient } from "@/lib/sanity";

async function getPosts() {
  if (!process.env.NEXT_PUBLIC_SANITY_PROJECT_ID) return [];
  return sanityClient.fetch(`*[_type == "post"] | order(publishedAt desc){title, excerpt, publishedAt, "slug": slug.current}`);
}

export default async function BlogPage() {
  const posts = await getPosts();
  return (
    <main className="mx-auto min-h-screen max-w-5xl px-6 pt-36 pb-24">
      <h1 className="text-5xl font-bold">Loggbok / Blogg</h1>
      <div className="mt-10 grid gap-6">
        {posts.length === 0 && (
          <GlassCard>
            <h2 className="text-2xl font-bold">Bloggen är redo för Sanity CMS</h2>
            <p className="mt-3 opacity-75">Lägg in dina Sanity-nycklar i .env.local och skapa posts i Sanity Studio.</p>
          </GlassCard>
        )}
        {posts.map((post: any) => (
          <GlassCard key={post.slug || post.title}>
            <h2 className="text-2xl font-bold">{post.title}</h2>
            <p className="mt-3 opacity-75">{post.excerpt}</p>
          </GlassCard>
        ))}
      </div>
    </main>
  );
}
