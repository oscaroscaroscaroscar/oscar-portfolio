'use client';
import { motion } from 'framer-motion';
import { Navbar } from '@/components/Navbar';
import { Background3D } from '@/components/Background3D';
import { ProjectCard } from '@/components/ProjectCard';
import { AIChat } from '@/components/AIChat';

const fade = {
  initial: { opacity: 0, y: 30 },
  whileInView: { opacity: 1, y: 0 },
  transition: { duration: 0.7 },
  viewport: { once: true }
};

export default function Home() {
  return (
    <main className="apple-bg min-h-screen overflow-hidden">
      <Navbar />
      <AIChat />

      <section id="home" className="relative min-h-screen flex items-center justify-center px-6 pt-24">
        <Background3D />
        <motion.div {...fade} className="relative z-10 mx-auto max-w-5xl text-center">
          <div className="inline-flex rounded-full glass px-4 py-2 text-sm text-white/70 mb-8">Digitala produkter • Webbplattformar • Kreativa projekt</div>
          <h1 className="text-5xl md:text-8xl font-semibold tracking-tight leading-[.95]">
            Oscar Åberg
            <span className="block bg-gradient-to-r from-white via-indigo-200 to-cyan-200 bg-clip-text text-transparent">Modern portfolio</span>
          </h1>
          <p className="mx-auto mt-8 max-w-2xl text-lg md:text-xl text-white/65 leading-relaxed">
            Jag utvecklar moderna webbplattformar, digitala tjänster och kreativa projekt med fokus på användarupplevelse, innovation och entreprenörskap.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row justify-center gap-4">
            <a href="#projects" className="rounded-full bg-white px-7 py-4 font-medium text-black hover:scale-105 transition">Se projekt</a>
            <a href="#contact" className="rounded-full glass px-7 py-4 font-medium hover:scale-105 transition">Kontakta mig</a>
          </div>
        </motion.div>
      </section>

      <section id="about" className="px-6 py-28">
        <motion.div {...fade} className="mx-auto max-w-6xl grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-4xl md:text-6xl font-semibold">Om mig</h2>
            <p className="mt-6 text-white/65 text-lg leading-relaxed">
              Jag är en teknikintresserad entreprenör som utvecklar digitala produkter, webbapplikationer och kreativa projekt. Mitt fokus ligger på att skapa användarvänliga lösningar som kombinerar design, funktionalitet och innovation.
            </p>
          </div>
          <div className="glass rounded-[2rem] p-8 neon">
            <h3 className="text-2xl font-semibold">Värderingar</h3>
            <div className="mt-6 grid grid-cols-2 gap-3 text-white/75">
              {['Kreativitet', 'Noggrannhet', 'Innovation', 'Lärande', 'Design', 'Entreprenörskap'].map(v => (
                <div key={v} className="rounded-2xl bg-white/10 p-4">{v}</div>
              ))}
            </div>
          </div>
        </motion.div>
      </section>

      <section id="projects" className="px-6 py-28">
        <motion.div {...fade} className="mx-auto max-w-6xl">
          <h2 className="text-4xl md:text-6xl font-semibold">Projekt & Portfolio</h2>
          <p className="mt-5 max-w-2xl text-white/60">Vissa projektkort är skyddade och visas först efter åtkomstkod.</p>
          <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ProjectCard locked title="CollectorsMarket" description="Modern marknadsplats för samlarobjekt med smarta verktyg för värdering, annonsering och försäljning." tools={['Next.js', 'Supabase', 'Stripe']} />
            <ProjectCard title="🎵 Musikplattform" description="Musik, media och kreativa digitala projekt." tools={['Media', 'Distribution', 'Webb']} />
            <ProjectCard locked title="Trading Dashboard" description="Privat dashboard för testmiljö, statistik och kontrollpanel." tools={['Python', 'FastAPI', 'Docker']} />
            <ProjectCard title="Global Travel Project" description="Långsiktigt rese- och planeringsprojekt med rutter, dokument och budgetstrategi." tools={['Planering', 'Research', 'Dokument']} />
            <ProjectCard title="Digitala Produkter" description="Webbapplikationer, designkoncept och entreprenöriella projekt." tools={['React', 'Design', 'SaaS']} />
            <ProjectCard locked title="Privat Projekt" description="Skyddat innehåll för utvalda besökare." tools={['Private', 'Roadmap']} />
          </div>
        </motion.div>
      </section>

      <section id="blog" className="px-6 py-28">
        <motion.div {...fade} className="mx-auto max-w-6xl glass rounded-[2rem] p-8 md:p-12 neon">
          <h2 className="text-4xl md:text-5xl font-semibold">Loggbok / Blogg</h2>
          <p className="mt-4 text-white/60">Redo att kopplas till Sanity CMS.</p>
          <div className="mt-8 grid md:grid-cols-3 gap-4">
            {['Från idé till produkt', 'Designsystem och portfolio', 'Musik, media och digital närvaro'].map(post => (
              <article key={post} className="rounded-3xl bg-white/10 p-6"><h3 className="font-semibold">{post}</h3><p className="mt-3 text-sm text-white/60">Kommande artikel.</p></article>
            ))}
          </div>
        </motion.div>
      </section>

      <section id="pricing" className="px-6 py-28">
        <motion.div {...fade} className="mx-auto max-w-6xl">
          <h2 className="text-4xl md:text-5xl font-semibold">Stripe-prissida</h2>
          <div className="mt-10 grid md:grid-cols-3 gap-6">
            {['Starter', 'Pro', 'Enterprise'].map((plan, i) => (
              <div key={plan} className="glass rounded-[2rem] p-8 neon">
                <h3 className="text-2xl font-semibold">{plan}</h3>
                <p className="mt-3 text-white/60">{i === 0 ? '99 kr/mån' : i === 1 ? '299 kr/mån' : 'Kontakta mig'}</p>
                <button className="mt-8 w-full rounded-full bg-white py-3 text-black">Välj</button>
              </div>
            ))}
          </div>
        </motion.div>
      </section>

      <footer id="contact" className="px-6 py-16 border-t border-white/10">
        <div className="mx-auto max-w-6xl flex flex-col md:flex-row justify-between gap-6 text-white/60">
          <div>
            <strong className="text-white">Oscar Åberg</strong>
            <p>© 2026. Byggd med Next.js, React och TypeScript.</p>
          </div>
          <a href="mailto:oscaraberg@gmail.com">oscaraberg@gmail.com</a>
        </div>
      </footer>
    </main>
  );
}
