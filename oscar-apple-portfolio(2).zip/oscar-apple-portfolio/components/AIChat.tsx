'use client';
import { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';

export function AIChat() {
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [reply, setReply] = useState('Hej! Jag kan svara på frågor om projekt, kontakt och samarbete.');

  async function send() {
    if (!message.trim()) return;
    setReply('Skriver...');
    try {
      const res = await fetch('/api/chat', { method: 'POST', body: JSON.stringify({ message }) });
      const data = await res.json();
      setReply(data.reply || 'Tack! Jag återkommer med svar.');
    } catch {
      setReply('Chatten är i demoläge tills API-nyckel är konfigurerad.');
    }
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {open && (
        <div className="mb-4 w-[340px] glass rounded-3xl p-4 shadow-glow">
          <div className="flex justify-between items-center">
            <strong>Assistent</strong>
            <button onClick={() => setOpen(false)}><X size={18} /></button>
          </div>
          <div className="my-4 rounded-2xl bg-white/10 p-3 text-sm text-white/75 min-h-[90px]">{reply}</div>
          <div className="flex gap-2">
            <input className="flex-1 rounded-2xl bg-black/30 border border-white/10 px-3 py-2 outline-none" value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Skriv fråga..." />
            <button onClick={send} className="rounded-2xl bg-white px-4 text-black">Skicka</button>
          </div>
        </div>
      )}
      <button onClick={() => setOpen(!open)} className="glass rounded-full p-4 shadow-glow hover:scale-105 transition">
        <MessageCircle />
      </button>
    </div>
  );
}
