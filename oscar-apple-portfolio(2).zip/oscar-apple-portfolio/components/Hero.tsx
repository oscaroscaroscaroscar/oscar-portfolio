"use client";
import { motion } from "framer-motion";
import Link from "next/link";

export default function Hero() {
  return (
    <section className="mx-auto flex min-h-screen max-w-6xl flex-col items-center justify-center px-6 pt-24 text-center">
      <motion.p initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="glass mb-5 rounded-full px-5 py-2 text-sm">
        AI • Portfolio • SaaS • Kreativa projekt
      </motion.p>
      <motion.h1 initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .1 }} className="max-w-5xl text-5xl font-bold tracking-tight md:text-8xl">
        Jag bygger framtidens digitala projekt med AI.
      </motion.h1>
      <motion.p initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .2 }} className="mt-7 max-w-2xl text-lg opacity-75 md:text-xl">
        Jag kombinerar artificiell intelligens, automation, design och entreprenörskap för att skapa appar, marknadsplatser, musiksystem och moderna webbupplevelser.
      </motion.p>
      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .3 }} className="mt-10 flex flex-wrap justify-center gap-4">
        <Link href="/projects" className="rounded-full bg-white px-7 py-4 font-semibold text-black hover:scale-105 transition">Se projekt</Link>
        <a href="mailto:oscaraberg@gmail.com" className="glass rounded-full px-7 py-4 font-semibold hover:scale-105 transition">Kontakta mig</a>
      </motion.div>
    </section>
  );
}
