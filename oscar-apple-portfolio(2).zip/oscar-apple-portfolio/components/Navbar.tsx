import { ThemeToggle } from './ThemeToggle';

export function Navbar() {
  return (
    <nav className="fixed top-4 left-1/2 z-50 w-[92%] max-w-6xl -translate-x-1/2 glass rounded-full px-5 py-3 flex items-center justify-between">
      <a href="#home" className="font-semibold tracking-tight">Oscar Åberg</a>
      <div className="hidden md:flex gap-6 text-sm text-white/70">
        <a href="#about">Om mig</a>
        <a href="#projects">Projekt</a>
        <a href="#blog">Blogg</a>
        <a href="#pricing">Priser</a>
        <a href="#contact">Kontakt</a>
      </div>
      <ThemeToggle />
    </nav>
  );
}
