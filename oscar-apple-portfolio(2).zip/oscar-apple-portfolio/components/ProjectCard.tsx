'use client';
import { useState } from 'react';
import { Lock, Unlock } from 'lucide-react';

const ACCESS_CODE = 'OSCAR2026';

type ProjectCardProps = {
  title: string;
  description: string;
  tools: string[];
  locked?: boolean;
};

export function ProjectCard({ title, description, tools, locked = false }: ProjectCardProps) {
  const [code, setCode] = useState('');
  const [unlocked, setUnlocked] = useState(!locked);
  const [error, setError] = useState('');

  function unlock() {
    if (code.trim() === ACCESS_CODE) {
      setUnlocked(true);
      setError('');
    } else {
      setError('Fel kod');
    }
  }

  if (!unlocked) {
    return (
      <div className="glass neon rounded-3xl p-6 min-h-[260px] flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-2 text-white/80"><Lock size={18} /> Skyddat projekt</div>
          <h3 className="mt-5 text-2xl font-semibold">Innehållet är låst</h3>
          <p className="mt-3 text-white/60">Ange åtkomstkod för att visa projektkortet.</p>
        </div>
        <div className="mt-6 space-y-3">
          <input
            value={code}
            onChange={(e) => setCode(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && unlock()}
            type="password"
            placeholder="Ange kod"
            className="w-full rounded-2xl border border-white/15 bg-black/30 px-4 py-3 outline-none focus:border-indigo-300"
          />
          <button onClick={unlock} className="w-full rounded-2xl bg-white text-black py-3 font-medium hover:scale-[1.02] transition">Lås upp</button>
          {error && <p className="text-sm text-red-300">{error}</p>}
        </div>
      </div>
    );
  }

  return (
    <div className="glass neon rounded-3xl p-6 min-h-[260px] hover:-translate-y-2 transition duration-300">
      <div className="flex items-center gap-2 text-emerald-300"><Unlock size={18} /> Upplåst</div>
      <h3 className="mt-5 text-2xl font-semibold">{title}</h3>
      <p className="mt-3 text-white/65 leading-relaxed">{description}</p>
      <div className="mt-6 flex flex-wrap gap-2">
        {tools.map((tool) => (
          <span key={tool} className="rounded-full border border-white/10 bg-white/10 px-3 py-1 text-xs text-white/70">{tool}</span>
        ))}
      </div>
    </div>
  );
}
