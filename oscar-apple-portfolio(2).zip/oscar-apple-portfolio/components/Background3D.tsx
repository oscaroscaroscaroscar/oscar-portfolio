'use client';
import { Canvas } from '@react-three/fiber';
import { Float, Sphere, Torus, MeshDistortMaterial } from '@react-three/drei';

function Objects() {
  return (
    <>
      <ambientLight intensity={1.2} />
      <pointLight position={[5, 5, 5]} intensity={1.5} />
      <Float speed={2} rotationIntensity={1.2} floatIntensity={1.4}>
        <Sphere args={[1.1, 64, 64]} position={[-2.6, .4, 0]}>
          <MeshDistortMaterial color="#6366f1" distort={0.35} speed={2} roughness={0.15} />
        </Sphere>
      </Float>
      <Float speed={1.6} rotationIntensity={1.6} floatIntensity={1.8}>
        <Torus args={[1, .22, 32, 100]} position={[2.3, -.15, 0]}>
          <meshStandardMaterial color="#22d3ee" roughness={0.18} metalness={0.55} />
        </Torus>
      </Float>
    </>
  );
}

export function Background3D() {
  return (
    <div className="absolute inset-0 opacity-70 pointer-events-none">
      <Canvas camera={{ position: [0, 0, 6], fov: 45 }}>
        <Objects />
      </Canvas>
    </div>
  );
}
